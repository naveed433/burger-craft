import React, { createContext, useContext, useReducer, ReactNode } from 'react';

// Types
interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
  customizations?: string[];
}

interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
}

interface Order {
  id: string;
  items: CartItem[];
  total: number;
  status: 'preparing' | 'cooking' | 'ready' | 'delivered';
  estimatedTime: string;
  date: string;
}

interface AppState {
  user: User | null;
  isAuthenticated: boolean;
  cart: CartItem[];
  orders: Order[];
  isLoading: boolean;
  currentLocation: string;
}

type AppAction =
  | { type: 'LOGIN'; payload: User }
  | { type: 'LOGOUT' }
  | { type: 'ADD_TO_CART'; payload: CartItem }
  | { type: 'REMOVE_FROM_CART'; payload: string }
  | { type: 'UPDATE_CART_QUANTITY'; payload: { id: string; quantity: number } }
  | { type: 'CLEAR_CART' }
  | { type: 'ADD_ORDER'; payload: Order }
  | { type: 'UPDATE_ORDER_STATUS'; payload: { id: string; status: Order['status'] } }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'CHANGE_LOCATION'; payload: string };

const initialState: AppState = {
  user: {
    id: '1',
    name: 'Naveed Khan',
    email: 'naveed@example.com',
    avatar: '/api/placeholder/150/150'
  },
  isAuthenticated: true, // Set to true for demo
  cart: [],
  orders: [
    {
      id: 'BRG-045',
      items: [
        {
          id: '1',
          name: 'Classic Supreme',
          price: 14.99,
          quantity: 1,
          image: 'https://images.unsplash.com/photo-1600555379885-08a02224726d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGVlc2VidXJnZXIlMjByZXN0YXVyYW50JTIwbWVhbHxlbnwxfHx8fDE3NTU0Mzk3MTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
        }
      ],
      total: 22.97,
      status: 'preparing',
      estimatedTime: '15-20 min',
      date: '2024-01-17'
    }
  ],
  isLoading: false,
  currentLocation: 'BurgerCraft Downtown, 123 Main Street'
};

const appReducer = (state: AppState, action: AppAction): AppState => {
  switch (action.type) {
    case 'LOGIN':
      return {
        ...state,
        user: action.payload,
        isAuthenticated: true
      };
    case 'LOGOUT':
      return {
        ...state,
        user: null,
        isAuthenticated: false,
        cart: []
      };
    case 'ADD_TO_CART':
      const existingItem = state.cart.find(item => item.id === action.payload.id);
      if (existingItem) {
        return {
          ...state,
          cart: state.cart.map(item =>
            item.id === action.payload.id
              ? { ...item, quantity: item.quantity + action.payload.quantity }
              : item
          )
        };
      }
      return {
        ...state,
        cart: [...state.cart, action.payload]
      };
    case 'REMOVE_FROM_CART':
      return {
        ...state,
        cart: state.cart.filter(item => item.id !== action.payload)
      };
    case 'UPDATE_CART_QUANTITY':
      return {
        ...state,
        cart: state.cart.map(item =>
          item.id === action.payload.id
            ? { ...item, quantity: action.payload.quantity }
            : item
        ).filter(item => item.quantity > 0)
      };
    case 'CLEAR_CART':
      return {
        ...state,
        cart: []
      };
    case 'ADD_ORDER':
      return {
        ...state,
        orders: [action.payload, ...state.orders],
        cart: []
      };
    case 'UPDATE_ORDER_STATUS':
      return {
        ...state,
        orders: state.orders.map(order =>
          order.id === action.payload.id
            ? { ...order, status: action.payload.status }
            : order
        )
      };
    case 'SET_LOADING':
      return {
        ...state,
        isLoading: action.payload
      };
    case 'CHANGE_LOCATION':
      return {
        ...state,
        currentLocation: action.payload
      };
    default:
      return state;
  }
};

const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
} | null>(null);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(appReducer, initialState);

  return (
    <AppContext.Provider value={{ state, dispatch }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};

// Custom hooks for specific actions
export const useCart = () => {
  const { state, dispatch } = useApp();

  const addToCart = (item: Omit<CartItem, 'quantity'>, quantity = 1) => {
    dispatch({
      type: 'ADD_TO_CART',
      payload: { ...item, quantity }
    });
  };

  const removeFromCart = (id: string) => {
    dispatch({ type: 'REMOVE_FROM_CART', payload: id });
  };

  const updateQuantity = (id: string, quantity: number) => {
    dispatch({ type: 'UPDATE_CART_QUANTITY', payload: { id, quantity } });
  };

  const clearCart = () => {
    dispatch({ type: 'CLEAR_CART' });
  };

  const cartTotal = state.cart.reduce((total, item) => total + (item.price * item.quantity), 0);
  const cartCount = state.cart.reduce((count, item) => count + item.quantity, 0);

  return {
    cart: state.cart,
    cartTotal,
    cartCount,
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart
  };
};

export const useAuth = () => {
  const { state, dispatch } = useApp();

  const login = (user: User) => {
    dispatch({ type: 'LOGIN', payload: user });
  };

  const logout = () => {
    dispatch({ type: 'LOGOUT' });
  };

  return {
    user: state.user,
    isAuthenticated: state.isAuthenticated,
    login,
    logout
  };
};

export const useOrders = () => {
  const { state, dispatch } = useApp();

  const placeOrder = (items: CartItem[]) => {
    const order: Order = {
      id: `BRG-${Date.now().toString().slice(-3)}`,
      items,
      total: items.reduce((total, item) => total + (item.price * item.quantity), 0),
      status: 'preparing',
      estimatedTime: '15-20 min',
      date: new Date().toISOString().split('T')[0]
    };
    dispatch({ type: 'ADD_ORDER', payload: order });
    return order;
  };

  const updateOrderStatus = (id: string, status: Order['status']) => {
    dispatch({ type: 'UPDATE_ORDER_STATUS', payload: { id, status } });
  };

  return {
    orders: state.orders,
    placeOrder,
    updateOrderStatus
  };
};