import { Header } from "./components/Header";
import { HeroSection } from "./components/HeroSection";
import { WelcomeBack } from "./components/WelcomeBack";
import { BurgerShowcase } from "./components/BurgerShowcase";
import { FullMenu } from "./components/FullMenu";
import { BurgerCustomizer } from "./components/BurgerCustomizer";
import { OrderTracker } from "./components/OrderTracker";
import { UserDashboard } from "./components/UserDashboard";
import { AppProvider } from "./contexts/AppContext";
import { ToastProvider } from "./components/ui/toast-provider";

export default function App() {
  return (
    <AppProvider>
      <ToastProvider>
        <div className="min-h-screen bg-white">
          <Header />
          <main>
            <HeroSection />
            <WelcomeBack />
            <BurgerShowcase />
            <FullMenu />
            <BurgerCustomizer />
            <OrderTracker />
            <UserDashboard />
          </main>
          
          {/* Footer */}
          <footer className="bg-gray-900 text-white py-12">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                      <span className="text-white font-bold">🍔</span>
                    </div>
                    <span className="font-bold text-xl">BurgerCraft</span>
                  </div>
                  <p className="text-gray-400 text-sm">
                    Crafting the perfect burger experience with premium ingredients and unmatched flavor.
                  </p>
                  <div className="space-y-2">
                    <p className="text-gray-400 text-sm">
                      📞 <a href="tel:03135957242" className="hover:text-white transition-colors">03135957242</a>
                    </p>
                    <p className="text-gray-400 text-sm">
                      ✉️ <a href="mailto:bilalnaveed676@gmail.com" className="hover:text-white transition-colors">bilalnaveed676@gmail.com</a>
                    </p>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-4">Menu</h4>
                  <ul className="space-y-2 text-sm text-gray-400">
                    <li><a href="#menu" className="hover:text-white transition-colors">Burgers</a></li>
                    <li><a href="#menu" className="hover:text-white transition-colors">Sides</a></li>
                    <li><a href="#menu" className="hover:text-white transition-colors">Drinks</a></li>
                    <li><a href="#menu" className="hover:text-white transition-colors">Desserts</a></li>
                  </ul>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-4">Company</h4>
                  <ul className="space-y-2 text-sm text-gray-400">
                    <li><a href="#" className="hover:text-white transition-colors">About Us</a></li>
                    <li><a href="#" className="hover:text-white transition-colors">Careers</a></li>
                    <li><a href="mailto:bilalnaveed676@gmail.com" className="hover:text-white transition-colors">Contact</a></li>
                    <li><a href="#" className="hover:text-white transition-colors">Locations</a></li>
                  </ul>
                </div>
                
                <div>
                  <h4 className="font-semibold mb-4">Support</h4>
                  <ul className="space-y-2 text-sm text-gray-400">
                    <li><a href="#" className="hover:text-white transition-colors">Help Center</a></li>
                    <li><a href="#track-order" className="hover:text-white transition-colors">Track Order</a></li>
                    <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
                    <li><a href="#" className="hover:text-white transition-colors">Terms of Service</a></li>
                  </ul>
                </div>
              </div>
              
              <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
                <p>&copy; 2024 BurgerCraft. All rights reserved. Made with ❤️ for burger lovers.</p>
              </div>
            </div>
          </footer>
        </div>
      </ToastProvider>
    </AppProvider>
  );
}