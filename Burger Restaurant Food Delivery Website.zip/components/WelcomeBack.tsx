import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { motion } from "motion/react";
import { 
  Heart, 
  Clock, 
  Star, 
  Gift,
  Repeat,
  MapPin,
  Sparkles 
} from "lucide-react";

export function WelcomeBack() {
  const userFavorites = [
    {
      id: "1",
      name: "The Classic Supreme",
      image: "https://images.unsplash.com/photo-1600555379885-08a02224726d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGVlc2VidXJnZXIlMjByZXN0YXVyYW50JTIwbWVhbHxlbnwxfHx8fDE3NTU0Mzk3MTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      price: 14.99,
      orderCount: 8,
      lastOrdered: "3 days ago"
    },
    {
      id: "2",
      name: "Spicy Chicken Deluxe",
      image: "https://images.unsplash.com/photo-1643111998354-07e7a780c92b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGlja2VuJTIwYnVyZ2VyJTIwZGVsaWNpb3VzfGVufDF8fHx8MTc1NTM0NTczNHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      price: 13.99,
      orderCount: 5,
      lastOrdered: "1 week ago"
    },
    {
      id: "3",
      name: "Bacon BBQ Beast",
      image: "https://images.unsplash.com/photo-1654779974049-e7d13ca21a90?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYWNvbiUyMGJ1cmdlciUyMGNyaXNweXxlbnwxfHx8fDE3NTU0Mzk3MTd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      price: 16.99,
      orderCount: 4,
      lastOrdered: "2 weeks ago"
    }
  ];

  const personalizedOffers = [
    {
      title: "Your Loyalty Reward",
      description: "Get 20% off your next Classic Supreme!",
      validUntil: "Valid until Jan 25",
      icon: "🎁",
      color: "bg-gradient-to-r from-primary to-red-600"
    },
    {
      title: "Spice Lover Special",
      description: "Free jalapeños on any spicy burger",
      validUntil: "This week only",
      icon: "🌶️",
      color: "bg-gradient-to-r from-red-500 to-orange-500"
    },
    {
      title: "Weekend Treat",
      description: "Free dessert with any burger combo",
      validUntil: "Weekends only",
      icon: "🍰",
      color: "bg-gradient-to-r from-purple-500 to-pink-500"
    }
  ];

  const recentOrders = [
    {
      id: "BRG-045",
      date: "3 days ago",
      items: ["Classic Supreme", "Large Fries", "Vanilla Shake"],
      total: 22.97,
      rating: 5
    },
    {
      id: "BRG-042",
      date: "1 week ago", 
      items: ["Spicy Chicken Deluxe", "Onion Rings"],
      total: 20.48,
      rating: 4
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-red-50 via-yellow-50 to-orange-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Welcome Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="inline-flex items-center space-x-2 bg-primary/10 backdrop-blur-sm rounded-full px-6 py-3 border border-primary/20 mb-6"
          >
            <Sparkles className="w-5 h-5 text-primary" />
            <span className="font-medium text-primary">Welcome Back, Naveed!</span>
            <span className="text-2xl">👋</span>
          </motion.div>
          
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4"
          >
            We've Missed You at <span className="text-primary">BurgerCraft</span>
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="text-lg text-gray-600 max-w-2xl mx-auto"
          >
            Ready for another delicious experience? We've prepared some special treats just for you!
          </motion.p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          {/* Your Favorites */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="lg:col-span-2"
          >
            <Card className="bg-white shadow-xl border-0">
              <CardContent className="p-8">
                <div className="flex items-center space-x-2 mb-6">
                  <Heart className="w-6 h-6 text-red-500 fill-red-500" />
                  <h3 className="text-2xl font-bold text-gray-900">Your Favorites</h3>
                  <Badge variant="secondary" className="ml-2">Based on your orders</Badge>
                </div>
                
                <div className="space-y-4">
                  {userFavorites.map((item, index) => (
                    <motion.div
                      key={item.id}
                      initial={{ opacity: 0, y: 20 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: index * 0.1 }}
                      className="flex items-center space-x-4 p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors group"
                    >
                      <div className="relative">
                        <div className="w-16 h-16 rounded-lg overflow-hidden">
                          <ImageWithFallback
                            src={item.image}
                            alt={item.name}
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                          />
                        </div>
                        <div className="absolute -top-2 -right-2 bg-primary text-white text-xs font-bold px-2 py-1 rounded-full">
                          #{index + 1}
                        </div>
                      </div>
                      
                      <div className="flex-1">
                        <h4 className="font-bold text-gray-900">{item.name}</h4>
                        <div className="flex items-center space-x-4 text-sm text-gray-600 mt-1">
                          <span>Ordered {item.orderCount} times</span>
                          <span>•</span>
                          <span>Last: {item.lastOrdered}</span>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-3">
                        <span className="text-lg font-bold text-primary">${item.price}</span>
                        <motion.div
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          <Button size="sm" className="bg-primary hover:bg-primary/90">
                            <Repeat className="w-4 h-4 mr-1" />
                            Reorder
                          </Button>
                        </motion.div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Quick Stats */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            {/* Stats Card */}
            <Card className="bg-gradient-to-br from-primary to-red-600 text-white shadow-xl border-0">
              <CardContent className="p-6">
                <div className="flex items-center space-x-2 mb-4">
                  <Star className="w-5 h-5 fill-white" />
                  <h3 className="text-lg font-bold">Your BurgerCraft Stats</h3>
                </div>
                
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="opacity-90">Total Orders:</span>
                    <span className="text-xl font-bold">24</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="opacity-90">Loyalty Points:</span>
                    <span className="text-xl font-bold">2,450</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="opacity-90">Member Since:</span>
                    <span className="font-semibold">Jan 2024</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="opacity-90">Favorite Day:</span>
                    <span className="font-semibold">Friday 🎉</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Location Reminder */}
            <Card className="bg-white shadow-lg border-0">
              <CardContent className="p-6">
                <div className="flex items-center space-x-2 mb-3">
                  <MapPin className="w-5 h-5 text-primary" />
                  <h4 className="font-bold text-gray-900">Your Usual Spot</h4>
                </div>
                <p className="text-gray-600 text-sm mb-4">
                  BurgerCraft Downtown<br />
                  123 Main Street<br />
                  Delivery: 15-20 mins
                </p>
                <Button variant="outline" size="sm" className="w-full">
                  <MapPin className="w-4 h-4 mr-1" />
                  Change Location
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Personalized Offers */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-12"
        >
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold text-gray-900 mb-2">
              <Gift className="w-6 h-6 inline mr-2 text-primary" />
              Special Offers Just for You
            </h3>
            <p className="text-gray-600">Personalized deals based on your preferences</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {personalizedOffers.map((offer, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.02 }}
                className={`${offer.color} rounded-2xl p-6 text-white shadow-lg cursor-pointer`}
              >
                <div className="text-4xl mb-3">{offer.icon}</div>
                <h4 className="font-bold text-lg mb-2">{offer.title}</h4>
                <p className="opacity-90 mb-3">{offer.description}</p>
                <p className="text-sm opacity-75">{offer.validUntil}</p>
                <Button 
                  variant="secondary" 
                  size="sm" 
                  className="mt-4 bg-white text-gray-900 hover:bg-gray-100"
                >
                  Claim Offer
                </Button>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Recent Orders */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <Card className="bg-white shadow-xl border-0">
            <CardContent className="p-8">
              <div className="flex items-center space-x-2 mb-6">
                <Clock className="w-6 h-6 text-primary" />
                <h3 className="text-2xl font-bold text-gray-900">Recent Orders</h3>
              </div>
              
              <div className="space-y-4">
                {recentOrders.map((order, index) => (
                  <motion.div
                    key={order.id}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    className="flex items-center justify-between p-4 bg-gray-50 rounded-xl"
                  >
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h4 className="font-bold text-gray-900">Order {order.id}</h4>
                        <span className="text-sm text-gray-500">{order.date}</span>
                        <div className="flex items-center">
                          {[...Array(order.rating)].map((_, i) => (
                            <Star key={i} className="w-4 h-4 fill-secondary text-secondary" />
                          ))}
                        </div>
                      </div>
                      <p className="text-gray-600 text-sm">{order.items.join(", ")}</p>
                    </div>
                    
                    <div className="flex items-center space-x-4">
                      <span className="text-lg font-bold text-primary">${order.total}</span>
                      <Button variant="outline" size="sm">
                        <Repeat className="w-4 h-4 mr-1" />
                        Reorder
                      </Button>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </section>
  );
}