import { useState } from "react";
import { Button } from "./ui/button";
import { ModernButton } from "./ui/modern-button";
import { AuthModal } from "./AuthModal";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "./ui/dropdown-menu";
import { motion } from "motion/react";
import { useAuth, useCart } from "../contexts/AppContext";
import { useToast } from "./ui/toast-provider";
import { 
  Menu, 
  X, 
  ShoppingCart, 
  User, 
  Settings, 
  LogOut, 
  MapPin, 
  Bell,
  Heart,
  Sparkles
} from "lucide-react";

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');
  
  const { user, isAuthenticated, logout } = useAuth();
  const { cartCount, cartTotal } = useCart();
  const { addToast } = useToast();

  const handleAuthClick = (mode: 'signin' | 'signup') => {
    setAuthMode(mode);
    setAuthModalOpen(true);
  };

  const handleLogout = () => {
    logout();
    addToast({
      type: 'success',
      title: 'Signed out successfully',
      description: 'You have been logged out of your account.'
    });
  };

  const handleCartClick = () => {
    if (cartCount > 0) {
      addToast({
        type: 'info',
        title: 'Cart Summary',
        description: `${cartCount} items • Total: $${cartTotal.toFixed(2)}`,
        action: {
          label: 'View Cart',
          onClick: () => console.log('Navigate to cart')
        }
      });
    } else {
      addToast({
        type: 'info',
        title: 'Your cart is empty',
        description: 'Add some delicious burgers to get started!'
      });
    }
  };

  return (
    <>
      <motion.header 
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ type: "spring", stiffness: 300, damping: 30 }}
        className="sticky top-0 z-50 bg-white/80 backdrop-blur-xl border-b border-gray-200/50 shadow-lg"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <motion.div 
              className="flex items-center space-x-2 cursor-pointer"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            >
              <motion.div 
                className="w-10 h-10 bg-gradient-to-r from-primary to-red-600 rounded-xl flex items-center justify-center shadow-lg"
                whileHover={{ rotate: 15 }}
                transition={{ type: "spring", stiffness: 400 }}
              >
                <span className="text-white font-bold text-lg">🍔</span>
              </motion.div>
              <span className="text-xl font-bold bg-gradient-to-r from-primary to-red-600 bg-clip-text text-transparent">
                BurgerCraft
              </span>
            </motion.div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-8">
              {[
                { name: 'Menu', href: '#menu' },
                { name: 'Customize', href: '#customize' },
                { name: 'Track Order', href: '#track-order', id: 'track-order' },
                { name: 'About', href: '#about' },
              ].map((item, index) => (
                <motion.a
                  key={item.name}
                  href={item.href}
                  id={item.id}
                  className="text-gray-700 hover:text-primary font-medium transition-colors relative group"
                  whileHover={{ y: -2 }}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  {item.name}
                  <motion.div
                    className="absolute -bottom-1 left-0 w-0 h-0.5 bg-gradient-to-r from-primary to-red-600 group-hover:w-full transition-all duration-300"
                  />
                </motion.a>
              ))}
            </nav>

            {/* Right side actions */}
            <div className="flex items-center space-x-4">
              {/* Location */}
              <motion.button
                className="hidden sm:flex items-center space-x-2 text-gray-600 hover:text-primary transition-colors"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => {
                  addToast({
                    type: 'info',
                    title: 'Change Location',
                    description: 'Location selection feature coming soon!',
                  });
                }}
              >
                <MapPin className="w-4 h-4" />
                <span className="text-sm font-medium">Downtown</span>
              </motion.button>

              {/* Cart */}
              <motion.button
                className="relative p-2"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={handleCartClick}
              >
                <ShoppingCart className="w-6 h-6 text-gray-700" />
                {cartCount > 0 && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute -top-1 -right-1"
                  >
                    <Badge className="bg-primary text-white text-xs px-1.5 py-0.5 rounded-full min-w-[20px] h-5 flex items-center justify-center">
                      {cartCount}
                    </Badge>
                  </motion.div>
                )}
              </motion.button>

              {/* Authentication */}
              {isAuthenticated && user ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <motion.button
                      className="flex items-center space-x-2 p-1 rounded-full hover:bg-gray-100 transition-colors"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <Avatar className="w-8 h-8">
                        <AvatarImage src={user.avatar} alt={user.name} />
                        <AvatarFallback className="bg-gradient-to-r from-primary to-red-600 text-white font-semibold">
                          {user.name.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      <span className="hidden sm:block text-sm font-medium text-gray-700">
                        {user.name.split(' ')[0]}
                      </span>
                    </motion.button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56 p-2">
                    <DropdownMenuItem className="flex items-center space-x-2 p-3 rounded-lg cursor-pointer">
                      <User className="w-4 h-4" />
                      <span>Profile</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem className="flex items-center space-x-2 p-3 rounded-lg cursor-pointer">
                      <Heart className="w-4 h-4" />
                      <span>Favorites</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem className="flex items-center space-x-2 p-3 rounded-lg cursor-pointer">
                      <Bell className="w-4 h-4" />
                      <span>Notifications</span>
                    </DropdownMenuItem>
                    <DropdownMenuItem className="flex items-center space-x-2 p-3 rounded-lg cursor-pointer">
                      <Settings className="w-4 h-4" />
                      <span>Settings</span>
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem 
                      className="flex items-center space-x-2 p-3 rounded-lg cursor-pointer text-red-600 hover:text-red-700"
                      onClick={handleLogout}
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Sign Out</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <div className="hidden sm:flex items-center space-x-3">
                  <ModernButton
                    variant="ghost"
                    size="sm"
                    onClick={() => handleAuthClick('signin')}
                    icon={<User className="w-4 h-4" />}
                  >
                    Sign In
                  </ModernButton>
                  <ModernButton
                    variant="primary"
                    size="sm"
                    onClick={() => handleAuthClick('signup')}
                    icon={<Sparkles className="w-4 h-4" />}
                    glow="intense"
                  >
                    Sign Up
                  </ModernButton>
                </div>
              )}

              {/* Mobile menu button */}
              <motion.button
                className="md:hidden p-2"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? (
                  <X className="w-6 h-6 text-gray-700" />
                ) : (
                  <Menu className="w-6 h-6 text-gray-700" />
                )}
              </motion.button>
            </div>
          </div>

          {/* Mobile menu */}
          <motion.div
            className={`md:hidden transition-all duration-300 ease-in-out ${
              isMenuOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
            } overflow-hidden`}
          >
            <div className="py-4 space-y-4 border-t border-gray-200">
              {[
                { name: 'Menu', href: '#menu' },
                { name: 'Customize', href: '#customize' },
                { name: 'Track Order', href: '#track-order' },
                { name: 'About', href: '#about' },
              ].map((item) => (
                <motion.a
                  key={item.name}
                  href={item.href}
                  className="block px-4 py-3 text-gray-700 hover:text-primary hover:bg-gray-50 rounded-lg font-medium transition-all"
                  onClick={() => setIsMenuOpen(false)}
                  whileHover={{ x: 8 }}
                >
                  {item.name}
                </motion.a>
              ))}
              
              {!isAuthenticated && (
                <div className="px-4 pt-4 space-y-3 border-t border-gray-200">
                  <ModernButton
                    variant="ghost"
                    size="sm"
                    className="w-full"
                    onClick={() => {
                      handleAuthClick('signin');
                      setIsMenuOpen(false);
                    }}
                    icon={<User className="w-4 h-4" />}
                  >
                    Sign In
                  </ModernButton>
                  <ModernButton
                    variant="primary"
                    size="sm"
                    className="w-full"
                    onClick={() => {
                      handleAuthClick('signup');
                      setIsMenuOpen(false);
                    }}
                    icon={<Sparkles className="w-4 h-4" />}
                    glow="intense"
                  >
                    Sign Up
                  </ModernButton>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      </motion.header>

      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        defaultMode={authMode}
      />
    </>
  );
}