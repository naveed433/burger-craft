import React, { createContext, useContext, useState, useCallback, forwardRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle, XCircle, AlertCircle, Info, X } from 'lucide-react';

type ToastType = 'success' | 'error' | 'warning' | 'info';

interface Toast {
  id: string;
  type: ToastType;
  title: string;
  description?: string;
  duration?: number;
  action?: {
    label: string;
    onClick: () => void;
  };
}

interface ToastContextType {
  addToast: (toast: Omit<Toast, 'id'>) => void;
  removeToast: (id: string) => void;
}

const ToastContext = createContext<ToastContextType | null>(null);

const getToastIcon = (type: ToastType) => {
  const iconClass = "w-5 h-5";
  switch (type) {
    case 'success': return <CheckCircle className={`${iconClass} text-green-500`} />;
    case 'error': return <XCircle className={`${iconClass} text-red-500`} />;
    case 'warning': return <AlertCircle className={`${iconClass} text-yellow-500`} />;
    case 'info': return <Info className={`${iconClass} text-blue-500`} />;
    default: return <Info className={`${iconClass} text-blue-500`} />;
  }
};

const getToastColors = (type: ToastType) => {
  switch (type) {
    case 'success': return 'bg-green-50 border-green-200 text-green-800';
    case 'error': return 'bg-red-50 border-red-200 text-red-800';
    case 'warning': return 'bg-yellow-50 border-yellow-200 text-yellow-800';
    case 'info': return 'bg-blue-50 border-blue-200 text-blue-800';
    default: return 'bg-blue-50 border-blue-200 text-blue-800';
  }
};

const ToastComponent = forwardRef<HTMLDivElement, { toast: Toast; onRemove: (id: string) => void }>(
  ({ toast, onRemove }, ref) => {
    const [isVisible, setIsVisible] = useState(true);

    React.useEffect(() => {
      const timer = setTimeout(() => {
        setIsVisible(false);
        setTimeout(() => onRemove(toast.id), 300);
      }, toast.duration || 5000);

      return () => clearTimeout(timer);
    }, [toast.id, toast.duration, onRemove]);

    const handleClose = () => {
      setIsVisible(false);
      setTimeout(() => onRemove(toast.id), 300);
    };

    if (!isVisible) return null;

    return (
      <motion.div
        ref={ref}
        initial={{ opacity: 0, x: 300, scale: 0.3 }}
        animate={{ opacity: 1, x: 0, scale: 1 }}
        exit={{ opacity: 0, x: 300, scale: 0.3 }}
        transition={{
          type: "spring",
          stiffness: 500,
          damping: 30
        }}
        className={`
          relative p-4 rounded-xl border shadow-lg backdrop-blur-sm max-w-sm w-full
          ${getToastColors(toast.type)}
        `}
      >
        <div className="flex items-start space-x-3">
          <motion.div
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 400 }}
          >
            {getToastIcon(toast.type)}
          </motion.div>
          
          <div className="flex-1 min-w-0">
            <motion.p
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="font-semibold text-sm"
            >
              {toast.title}
            </motion.p>
            
            {toast.description && (
              <motion.p
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="text-xs mt-1 opacity-90"
              >
                {toast.description}
              </motion.p>
            )}
            
            {toast.action && (
              <motion.button
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.3 }}
                onClick={toast.action.onClick}
                className="mt-2 text-xs font-medium underline hover:no-underline transition-all"
              >
                {toast.action.label}
              </motion.button>
            )}
          </div>
          
          <motion.button
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
            onClick={handleClose}
            className="flex-shrink-0 p-1 rounded-full hover:bg-black/10 transition-colors"
          >
            <X className="w-4 h-4" />
          </motion.button>
        </div>
        
        {/* Progress bar */}
        <motion.div
          initial={{ scaleX: 1 }}
          animate={{ scaleX: 0 }}
          transition={{ duration: (toast.duration || 5000) / 1000, ease: "linear" }}
          className="absolute bottom-0 left-0 h-1 bg-current opacity-30 rounded-full"
          style={{ transformOrigin: "left" }}
        />
      </motion.div>
    );
  }
);

ToastComponent.displayName = "ToastComponent";

export const ToastProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const addToast = useCallback((toast: Omit<Toast, 'id'>) => {
    const id = Math.random().toString(36).substr(2, 9);
    setToasts(prev => [...prev, { ...toast, id }]);
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts(prev => prev.filter(toast => toast.id !== id));
  }, []);

  return (
    <ToastContext.Provider value={{ addToast, removeToast }}>
      {children}
      
      {/* Toast container */}
      <div className="fixed top-4 right-4 z-[9999] space-y-3">
        <AnimatePresence mode="popLayout">
          {toasts.map(toast => (
            <ToastComponent
              key={toast.id}
              toast={toast}
              onRemove={removeToast}
            />
          ))}
        </AnimatePresence>
      </div>
    </ToastContext.Provider>
  );
};

export const useToast = () => {
  const context = useContext(ToastContext);
  if (!context) {
    throw new Error('useToast must be used within a ToastProvider');
  }
  return context;
};

// Convenience functions
export const toast = {
  success: (title: string, description?: string, options?: Partial<Toast>) => {
    const context = React.useContext(ToastContext);
    if (context) {
      context.addToast({ type: 'success', title, description, ...options });
    }
  },
  error: (title: string, description?: string, options?: Partial<Toast>) => {
    const context = React.useContext(ToastContext);
    if (context) {
      context.addToast({ type: 'error', title, description, ...options });
    }
  },
  warning: (title: string, description?: string, options?: Partial<Toast>) => {
    const context = React.useContext(ToastContext);
    if (context) {
      context.addToast({ type: 'warning', title, description, ...options });
    }
  },
  info: (title: string, description?: string, options?: Partial<Toast>) => {
    const context = React.useContext(ToastContext);
    if (context) {
      context.addToast({ type: 'info', title, description, ...options });
    }
  },
};