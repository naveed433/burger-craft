import * as React from "react";
import { motion } from "motion/react";
import { cva, type VariantProps } from "class-variance-authority@0.7.1";
import { cn } from "./utils";

const modernButtonVariants = cva(
  "relative inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-xl font-medium transition-all duration-300 disabled:pointer-events-none disabled:opacity-50 overflow-hidden group active:scale-95",
  {
    variants: {
      variant: {
        primary: "bg-gradient-to-r from-primary via-red-600 to-primary text-white shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/40 border border-primary/20",
        secondary: "bg-gradient-to-r from-secondary via-yellow-500 to-secondary text-black shadow-lg shadow-secondary/25 hover:shadow-xl hover:shadow-secondary/40 border border-secondary/20",
        success: "bg-gradient-to-r from-green-500 via-green-600 to-green-500 text-white shadow-lg shadow-green-500/25 hover:shadow-xl hover:shadow-green-500/40 border border-green-500/20",
        outline: "bg-gradient-to-r from-white to-gray-50 text-primary border-2 border-primary/20 hover:border-primary/40 shadow-lg hover:shadow-xl backdrop-blur-sm",
        glass: "bg-white/10 backdrop-blur-md border border-white/20 text-white hover:bg-white/20 shadow-lg hover:shadow-xl",
        ghost: "bg-transparent hover:bg-primary/10 text-primary border border-transparent hover:border-primary/20",
        danger: "bg-gradient-to-r from-red-500 via-red-600 to-red-500 text-white shadow-lg shadow-red-500/25 hover:shadow-xl hover:shadow-red-500/40 border border-red-500/20",
      },
      size: {
        sm: "h-9 px-4 py-2 text-sm rounded-lg",
        default: "h-11 px-6 py-3 text-base rounded-xl",
        lg: "h-14 px-8 py-4 text-lg rounded-2xl",
        xl: "h-16 px-10 py-5 text-xl rounded-2xl",
        icon: "size-11 rounded-xl",
      },
      glow: {
        none: "",
        subtle: "before:absolute before:inset-0 before:rounded-[inherit] before:bg-gradient-to-r before:from-white/20 before:to-transparent before:opacity-0 hover:before:opacity-100 before:transition-opacity",
        intense: "before:absolute before:inset-0 before:rounded-[inherit] before:bg-gradient-to-r before:from-white/30 before:via-white/10 before:to-transparent before:opacity-0 hover:before:opacity-100 before:transition-all before:duration-300",
      }
    },
    defaultVariants: {
      variant: "primary",
      size: "default",
      glow: "subtle",
    },
  }
);

interface ModernButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof modernButtonVariants> {
  loading?: boolean;
  icon?: React.ReactNode;
  rightIcon?: React.ReactNode;
  ripple?: boolean;
}

const ModernButton = React.forwardRef<HTMLButtonElement, ModernButtonProps>(
  ({ 
    className, 
    variant, 
    size, 
    glow,
    loading = false,
    icon,
    rightIcon,
    ripple = true,
    children, 
    onClick,
    disabled,
    ...props 
  }, ref) => {
    const [ripples, setRipples] = React.useState<Array<{ id: number; x: number; y: number }>>([]);
    const buttonRef = React.useRef<HTMLButtonElement>(null);

    React.useImperativeHandle(ref, () => buttonRef.current!);

    const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
      if (disabled || loading) return;

      if (ripple && buttonRef.current) {
        const rect = buttonRef.current.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const newRipple = { id: Date.now(), x, y };
        
        setRipples(prev => [...prev, newRipple]);
        
        setTimeout(() => {
          setRipples(prev => prev.filter(ripple => ripple.id !== newRipple.id));
        }, 600);
      }

      onClick?.(e);
    };

    return (
      <motion.button
        ref={buttonRef}
        className={cn(modernButtonVariants({ variant, size, glow, className }))}
        onClick={handleClick}
        disabled={disabled || loading}
        whileHover={{ 
          scale: 1.05,
          y: -2,
        }}
        whileTap={{ 
          scale: 0.95,
          y: 0,
        }}
        transition={{
          type: "spring",
          stiffness: 400,
          damping: 17
        }}
        {...props}
      >
        {/* Shimmer effect */}
        <div className="absolute inset-0 -top-[1px] bg-gradient-to-r from-transparent via-white/20 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000 ease-out" />
        
        {/* Ripple effects */}
        {ripples.map((ripple) => (
          <motion.span
            key={ripple.id}
            className="absolute bg-white/30 rounded-full pointer-events-none"
            style={{
              left: ripple.x,
              top: ripple.y,
            }}
            initial={{ width: 0, height: 0, x: '-50%', y: '-50%' }}
            animate={{ width: 200, height: 200, opacity: 0 }}
            transition={{ duration: 0.6, ease: "easeOut" }}
          />
        ))}

        {/* Content */}
        <span className="relative z-10 flex items-center gap-2">
          {loading ? (
            <motion.div
              className="w-4 h-4 border-2 border-current border-t-transparent rounded-full"
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            />
          ) : icon ? (
            <motion.span
              className="inline-flex"
              initial={{ scale: 1 }}
              whileHover={{ scale: 1.1, rotate: 5 }}
            >
              {icon}
            </motion.span>
          ) : null}
          
          {children}
          
          {rightIcon && (
            <motion.span
              className="inline-flex"
              initial={{ scale: 1 }}
              whileHover={{ scale: 1.1, rotate: -5 }}
            >
              {rightIcon}
            </motion.span>
          )}
        </span>

        {/* Glow effect */}
        <div className="absolute inset-0 rounded-[inherit] bg-gradient-to-r from-white/0 via-white/10 to-white/0 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      </motion.button>
    );
  }
);

ModernButton.displayName = "ModernButton";

export { ModernButton, modernButtonVariants };
export type { ModernButtonProps };