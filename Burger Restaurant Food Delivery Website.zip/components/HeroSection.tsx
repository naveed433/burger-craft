import { motion } from "motion/react";
import { ModernButton } from "./ui/modern-button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { useToast } from "./ui/toast-provider";
import { ArrowRight, Sparkles, ChefHat, Zap, Star } from "lucide-react";

export function HeroSection() {
  const { addToast } = useToast();

  const handleOrderNow = () => {
    addToast({
      type: 'success',
      title: 'Let\'s get cooking! 🍔',
      description: 'Scrolling to our delicious menu...',
    });
    
    setTimeout(() => {
      document.getElementById('menu')?.scrollIntoView({ 
        behavior: 'smooth',
        block: 'start'
      });
    }, 500);
  };

  const handleCustomize = () => {
    addToast({
      type: 'info',
      title: 'Customize Your Perfect Burger! ✨',
      description: 'Create your dream burger with our interactive customizer.',
    });
    
    setTimeout(() => {
      document.getElementById('customize')?.scrollIntoView({ 
        behavior: 'smooth',
        block: 'start'
      });
    }, 500);
  };

  // Floating ingredients animation
  const floatingIngredients = [
    { emoji: "🍅", delay: 0, x: 100, y: 50 },
    { emoji: "🧀", delay: 0.5, x: -80, y: 80 },
    { emoji: "🥬", delay: 1, x: 120, y: -60 },
    { emoji: "🥓", delay: 1.5, x: -100, y: -40 },
    { emoji: "🧅", delay: 2, x: 80, y: 100 },
  ];

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-red-50 via-yellow-50 to-orange-50">
      {/* Background Pattern */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(198,40,40,0.1),transparent_50%),radial-gradient(circle_at_70%_80%,rgba(255,193,7,0.1),transparent_50%)]" />
      
      {/* Floating Ingredients */}
      {floatingIngredients.map((ingredient, index) => (
        <motion.div
          key={index}
          className="absolute text-4xl sm:text-6xl opacity-20 pointer-events-none"
          initial={{ 
            opacity: 0, 
            scale: 0,
            x: ingredient.x,
            y: ingredient.y,
          }}
          animate={{ 
            opacity: 0.3,
            scale: 1,
            y: [ingredient.y, ingredient.y - 20, ingredient.y],
            rotate: [0, 10, -10, 0],
          }}
          transition={{
            delay: ingredient.delay,
            duration: 4,
            repeat: Infinity,
            repeatType: "reverse",
            ease: "easeInOut",
          }}
          style={{
            left: `${50 + ingredient.x}px`,
            top: `${50 + ingredient.y}px`,
          }}
        >
          {ingredient.emoji}
        </motion.div>
      ))}

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="text-center lg:text-left space-y-8"
          >
            {/* Badge */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="inline-flex items-center space-x-2 bg-white/80 backdrop-blur-sm rounded-full px-4 py-2 border border-primary/20 shadow-lg"
            >
              <Star className="w-4 h-4 text-secondary fill-secondary" />
              <span className="text-sm font-medium text-primary">Premium Quality Since 2024</span>
            </motion.div>

            {/* Main Heading */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="space-y-4"
            >
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight">
                Craft Your Perfect{" "}
                <span className="bg-gradient-to-r from-primary via-red-500 to-primary bg-clip-text text-transparent">
                  Burger
                </span>{" "}
                Experience
              </h1>
              <p className="text-lg sm:text-xl text-gray-600 max-w-2xl">
                Premium ingredients, handcrafted perfection, and unmatched flavor in every bite. 
                Welcome to the future of burger crafting.
              </p>
            </motion.div>

            {/* Stats */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="flex flex-wrap justify-center lg:justify-start gap-6 text-center"
            >
              {[
                { number: "50K+", label: "Happy Customers" },
                { number: "4.9★", label: "Average Rating" },
                { number: "15min", label: "Avg Delivery" },
              ].map((stat, index) => (
                <motion.div
                  key={stat.label}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.8 + index * 0.1, type: "spring" }}
                  className="bg-white/60 backdrop-blur-sm rounded-xl p-4 border border-white/40 shadow-lg"
                >
                  <div className="text-2xl font-bold text-primary">{stat.number}</div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </motion.div>
              ))}
            </motion.div>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.8 }}
              className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start"
            >
              <ModernButton
                variant="primary"
                size="xl"
                onClick={handleOrderNow}
                rightIcon={<ArrowRight className="w-5 h-5" />}
                glow="intense"
                className="group"
              >
                <Zap className="w-5 h-5 group-hover:animate-pulse" />
                Order Now
              </ModernButton>
              
              <ModernButton
                variant="outline"
                size="xl"
                onClick={handleCustomize}
                rightIcon={<Sparkles className="w-5 h-5" />}
                className="group"
              >
                <ChefHat className="w-5 h-5 group-hover:rotate-12 transition-transform" />
                Customize Burger
              </ModernButton>
            </motion.div>

            {/* Trust Indicators */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1 }}
              className="flex items-center justify-center lg:justify-start space-x-6 text-gray-500"
            >
              <div className="flex items-center space-x-2">
                <span className="text-2xl">🚚</span>
                <span className="text-sm">Fast Delivery</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-2xl">🌱</span>
                <span className="text-sm">Fresh Ingredients</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-2xl">🔒</span>
                <span className="text-sm">Secure Payment</span>
              </div>
            </motion.div>
          </motion.div>

          {/* Right Content - Hero Image */}
          <motion.div
            initial={{ opacity: 0, x: 50, scale: 0.8 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="relative"
          >
            <motion.div
              animate={{ 
                y: [0, -10, 0],
                rotate: [0, 2, -2, 0],
              }}
              transition={{
                duration: 6,
                repeat: Infinity,
                ease: "easeInOut",
              }}
              className="relative z-10"
            >
              <div className="relative w-full max-w-lg mx-auto">
                {/* Glow effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-secondary/20 rounded-full blur-3xl scale-110" />
                
                {/* Main burger image */}
                <div className="relative bg-white/10 backdrop-blur-sm rounded-full p-8 border border-white/20 shadow-2xl">
                  <ImageWithFallback
                    src="https://images.unsplash.com/photo-1600555379885-08a02224726d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGVlc2VidXJnZXIlMjByZXN0YXVyYW50JTIwbWVhbHxlbnwxfHx8fDE3NTU0Mzk3MTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                    alt="Premium BurgerCraft Burger"
                    className="w-full h-auto rounded-full shadow-2xl"
                  />
                </div>

                {/* Floating elements around the burger */}
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
                  className="absolute inset-0"
                >
                  {[
                    { emoji: "⭐", position: "top-4 left-4" },
                    { emoji: "🔥", position: "top-4 right-4" },
                    { emoji: "💯", position: "bottom-4 left-4" },
                    { emoji: "❤️", position: "bottom-4 right-4" },
                  ].map((item, index) => (
                    <motion.div
                      key={index}
                      className={`absolute ${item.position} text-2xl`}
                      animate={{ scale: [1, 1.2, 1] }}
                      transition={{ 
                        duration: 2, 
                        repeat: Infinity, 
                        delay: index * 0.5,
                        ease: "easeInOut" 
                      }}
                    >
                      {item.emoji}
                    </motion.div>
                  ))}
                </motion.div>
              </div>
            </motion.div>

            {/* Background decoration */}
            <div className="absolute inset-0 -z-10">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 50, repeat: Infinity, ease: "linear" }}
                className="w-full h-full rounded-full bg-gradient-to-r from-primary/5 to-secondary/5 blur-xl"
              />
            </div>
          </motion.div>
        </div>
      </div>

      {/* Bottom wave */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg
          className="w-full h-16 fill-white"
          viewBox="0 0 1440 74"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path d="M0,32L48,37.3C96,43,192,53,288,58.7C384,64,480,64,576,58.7C672,53,768,43,864,42.7C960,43,1056,53,1152,58.7C1248,64,1344,64,1392,64L1440,64L1440,74L1392,74C1344,74,1248,74,1152,74C1056,74,960,74,864,74C768,74,672,74,576,74C480,74,384,74,288,74C192,74,96,74,48,74L0,74Z" />
        </svg>
      </div>
    </section>
  );
}