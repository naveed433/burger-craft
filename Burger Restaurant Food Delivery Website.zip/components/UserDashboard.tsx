import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { motion } from "motion/react";
import { 
  User, 
  Heart, 
  Trophy, 
  Star, 
  Repeat, 
  Gift,
  Clock,
  MapPin,
  CreditCard
} from "lucide-react";

interface PastOrder {
  id: string;
  date: string;
  items: string[];
  total: number;
  status: 'delivered' | 'cancelled';
  rating?: number;
}

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  isUnlocked: boolean;
  progress?: number;
  maxProgress?: number;
}

export function UserDashboard() {
  const [user] = useState({
    name: "Naveed Khan",
    email: "naveed@example.com",
    avatar: "/api/placeholder/150/150",
    memberSince: "January 2024",
    totalOrders: 24,
    loyaltyPoints: 2450,
    nextRewardAt: 3000,
    currentLevel: "Burger Enthusiast",
    nextLevel: "Burger Master"
  });

  const [pastOrders] = useState<PastOrder[]>([
    {
      id: "BRG-001",
      date: "2024-01-15",
      items: ["Classic Supreme", "Spicy Chicken Deluxe", "Large Fries"],
      total: 34.96,
      status: "delivered",
      rating: 5
    },
    {
      id: "BRG-002", 
      date: "2024-01-12",
      items: ["Bacon BBQ Beast", "Garden Veggie Bliss"],
      total: 29.98,
      status: "delivered",
      rating: 4
    },
    {
      id: "BRG-003",
      date: "2024-01-10",
      items: ["Classic Supreme", "Onion Rings"],
      total: 18.49,
      status: "delivered",
      rating: 5
    }
  ]);

  const [favorites] = useState([
    { id: 1, name: "Classic Supreme", orderCount: 8, lastOrdered: "3 days ago" },
    { id: 2, name: "Spicy Chicken Deluxe", orderCount: 5, lastOrdered: "1 week ago" },
    { id: 3, name: "Bacon BBQ Beast", orderCount: 4, lastOrdered: "2 weeks ago" }
  ]);

  const [achievements] = useState<Achievement[]>([
    {
      id: "first-order",
      title: "First Bite",
      description: "Placed your first order",
      icon: "🎉",
      isUnlocked: true
    },
    {
      id: "loyal-customer",
      title: "Loyal Customer", 
      description: "Ordered 10 times",
      icon: "🏆",
      isUnlocked: true
    },
    {
      id: "spice-lover",
      title: "Spice Lover",
      description: "Order 5 spicy burgers",
      icon: "🌶️",
      isUnlocked: true
    },
    {
      id: "streak-master",
      title: "Streak Master",
      description: "Order 7 days in a row",
      icon: "🔥",
      isUnlocked: false,
      progress: 4,
      maxProgress: 7
    },
    {
      id: "big-spender",
      title: "Big Spender",
      description: "Spend $500 total",
      icon: "💰",
      isUnlocked: false,
      progress: 347,
      maxProgress: 500
    }
  ]);

  const loyaltyProgress = (user.loyaltyPoints / user.nextRewardAt) * 100;
  const pointsToNext = user.nextRewardAt - user.loyaltyPoints;

  return (
    <section className="py-20 bg-gradient-to-br from-gray-50 to-yellow-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            Welcome Back, <span className="text-primary">{user.name.split(' ')[0]}!</span> 👋
          </h2>
        </motion.div>

        {/* User Profile Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-8"
        >
          <Card className="bg-gradient-to-r from-primary to-red-600 text-white shadow-xl">
            <CardContent className="p-6">
              <div className="flex items-center space-x-6">
                <Avatar className="w-20 h-20 border-4 border-white">
                  <AvatarImage src={user.avatar} alt={user.name} />
                  <AvatarFallback className="bg-white text-primary text-xl font-bold">
                    {user.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                
                <div className="flex-1">
                  <h3 className="text-2xl font-bold mb-1">{user.name}</h3>
                  <p className="text-red-100 mb-3">{user.currentLevel}</p>
                  
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <div className="text-2xl font-bold">{user.totalOrders}</div>
                      <div className="text-sm text-red-100">Total Orders</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold">{user.loyaltyPoints}</div>
                      <div className="text-sm text-red-100">Points</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold">4.9★</div>
                      <div className="text-sm text-red-100">Avg Rating</div>
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <Button variant="secondary" size="sm" className="mb-3">
                    <User className="w-4 h-4 mr-1" />
                    Edit Profile
                  </Button>
                  <div className="text-sm text-red-100">
                    Member since {user.memberSince}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Loyalty Points Progress */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 }}
          className="mb-8"
        >
          <Card className="bg-white shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-bold text-lg flex items-center">
                  <Gift className="w-5 h-5 mr-2 text-secondary" />
                  Loyalty Rewards
                </h4>
                <Badge variant="secondary" className="font-bold">
                  {pointsToNext} points to next reward
                </Badge>
              </div>
              
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span>{user.currentLevel}</span>
                  <span>{user.nextLevel}</span>
                </div>
                <Progress value={loyaltyProgress} className="h-3" />
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600">
                    {user.loyaltyPoints} / {user.nextRewardAt} points
                  </span>
                  <motion.div
                    animate={{ scale: [1, 1.1, 1] }}
                    transition={{ repeat: Infinity, duration: 2 }}
                    className="text-2xl"
                  >
                    🎁
                  </motion.div>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Dashboard Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2 }}
        >
          <Tabs defaultValue="orders" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3 lg:w-auto lg:flex">
              <TabsTrigger value="orders" className="flex items-center space-x-2">
                <Clock className="w-4 h-4" />
                <span>Past Orders</span>
              </TabsTrigger>
              <TabsTrigger value="favorites" className="flex items-center space-x-2">
                <Heart className="w-4 h-4" />
                <span>Favorites</span>
              </TabsTrigger>
              <TabsTrigger value="achievements" className="flex items-center space-x-2">
                <Trophy className="w-4 h-4" />
                <span>Achievements</span>
              </TabsTrigger>
            </TabsList>

            {/* Past Orders Tab */}
            <TabsContent value="orders">
              <div className="grid gap-4">
                {pastOrders.map((order, index) => (
                  <motion.div
                    key={order.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card className="bg-white shadow-lg hover:shadow-xl transition-shadow">
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-4">
                          <div>
                            <h4 className="font-bold text-lg">Order {order.id}</h4>
                            <p className="text-gray-600 text-sm">
                              {new Date(order.date).toLocaleDateString('en-US', {
                                year: 'numeric',
                                month: 'long',
                                day: 'numeric'
                              })}
                            </p>
                          </div>
                          <div className="text-right">
                            <div className="text-2xl font-bold text-primary">
                              ${order.total.toFixed(2)}
                            </div>
                            {order.rating && (
                              <div className="flex items-center mt-1">
                                {[...Array(order.rating)].map((_, i) => (
                                  <Star key={i} className="w-4 h-4 fill-secondary text-secondary" />
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                        
                        <div className="mb-4">
                          <p className="text-gray-700 text-sm">
                            {order.items.join(', ')}
                          </p>
                        </div>

                        <div className="flex space-x-3">
                          <Button variant="outline" size="sm">
                            <Repeat className="w-4 h-4 mr-1" />
                            Reorder
                          </Button>
                          <Button variant="outline" size="sm">
                            <MapPin className="w-4 h-4 mr-1" />
                            Track
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </TabsContent>

            {/* Favorites Tab */}
            <TabsContent value="favorites">
              <div className="grid gap-4">
                {favorites.map((item, index) => (
                  <motion.div
                    key={item.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card className="bg-white shadow-lg hover:shadow-xl transition-shadow">
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-4">
                            <div className="text-4xl">🍔</div>
                            <div>
                              <h4 className="font-bold text-lg">{item.name}</h4>
                              <p className="text-gray-600 text-sm">
                                Ordered {item.orderCount} times • Last: {item.lastOrdered}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-3">
                            <Heart className="w-5 h-5 fill-red-500 text-red-500" />
                            <Button size="sm">
                              Order Again
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </TabsContent>

            {/* Achievements Tab */}
            <TabsContent value="achievements">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {achievements.map((achievement, index) => (
                  <motion.div
                    key={achievement.id}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card className={`${
                      achievement.isUnlocked 
                        ? 'bg-gradient-to-br from-secondary/20 to-primary/20 border-secondary' 
                        : 'bg-gray-50 border-gray-200'
                    } shadow-lg transition-all hover:shadow-xl`}>
                      <CardContent className="p-6">
                        <div className="flex items-start space-x-4">
                          <div className={`text-4xl ${!achievement.isUnlocked && 'grayscale opacity-50'}`}>
                            {achievement.icon}
                          </div>
                          <div className="flex-1">
                            <h4 className={`font-bold text-lg mb-1 ${
                              achievement.isUnlocked ? 'text-primary' : 'text-gray-500'
                            }`}>
                              {achievement.title}
                            </h4>
                            <p className="text-gray-600 text-sm mb-3">
                              {achievement.description}
                            </p>
                            
                            {!achievement.isUnlocked && achievement.progress !== undefined && (
                              <div className="space-y-2">
                                <Progress 
                                  value={(achievement.progress / achievement.maxProgress!) * 100} 
                                  className="h-2"
                                />
                                <p className="text-xs text-gray-500">
                                  {achievement.progress} / {achievement.maxProgress}
                                </p>
                              </div>
                            )}
                            
                            {achievement.isUnlocked && (
                              <Badge variant="secondary" className="font-bold">
                                ✓ Unlocked
                              </Badge>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </motion.div>
      </div>
    </section>
  );
}