import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "./ui/dialog";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { ModernButton } from "./ui/modern-button";
import { motion } from "motion/react";
import { Star, Clock, Flame, Plus, Minus } from "lucide-react";
import { useState } from "react";
import { useCart } from "../contexts/AppContext";
import { useToast } from "./ui/toast-provider";

interface Burger {
  id: string;
  name: string;
  description: string;
  fullDescription: string;
  price: number;
  image: string;
  rating: number;
  prepTime: string;
  isSpicy?: boolean;
  isPopular?: boolean;
  ingredients: string[];
  nutritionInfo: {
    calories: number;
    protein: string;
    carbs: string;
    fat: string;
  };
  allergens: string[];
}

export function BurgerShowcase() {
  const [hoveredBurger, setHoveredBurger] = useState<string | null>(null);
  const [selectedBurger, setSelectedBurger] = useState<Burger | null>(null);
  const [quantity, setQuantity] = useState(1);

  const { addToCart, cartCount, cartTotal } = useCart();
  const { addToast } = useToast();

  const featuredBurgers: Burger[] = [
    {
      id: "1",
      name: "The Classic Supreme",
      description: "Juicy beef patty, aged cheddar, crispy lettuce, tomato",
      fullDescription: "Our signature burger featuring a handcrafted 6oz beef patty made from premium ground chuck, topped with aged Vermont cheddar, crisp iceberg lettuce, vine-ripened tomatoes, red onion, and our secret sauce on a toasted brioche bun.",
      price: 14.99,
      image: "https://images.unsplash.com/photo-1600555379885-08a02224726d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGVlc2VidXJnZXIlMjByZXN0YXVyYW50JTIwbWVhbHxlbnwxfHx8fDE3NTU0Mzk3MTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 4.8,
      prepTime: "12-15 min",
      isPopular: true,
      ingredients: ["6oz Beef Patty", "Aged Cheddar", "Lettuce", "Tomato", "Red Onion", "Secret Sauce", "Brioche Bun"],
      nutritionInfo: {
        calories: 650,
        protein: "35g",
        carbs: "45g",
        fat: "28g"
      },
      allergens: ["Gluten", "Dairy", "Eggs"]
    },
    {
      id: "2",
      name: "Spicy Chicken Deluxe",
      description: "Crispy chicken breast, pepper jack, jalapeños, sriracha mayo",
      fullDescription: "Fire up your taste buds with our crispy buttermilk fried chicken breast, melted pepper jack cheese, fresh jalapeños, crisp lettuce, and house-made sriracha mayo on a toasted sesame bun.",
      price: 13.99,
      image: "https://images.unsplash.com/photo-1643111998354-07e7a780c92b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGlja2VuJTIwYnVyZ2VyJTIwZGVsaWNpb3VzfGVufDF8fHx8MTc1NTM0NTczNHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 4.6,
      prepTime: "10-12 min",
      isSpicy: true,
      ingredients: ["Crispy Chicken Breast", "Pepper Jack", "Jalapeños", "Lettuce", "Sriracha Mayo", "Sesame Bun"],
      nutritionInfo: {
        calories: 580,
        protein: "42g",
        carbs: "38g",
        fat: "22g"
      },
      allergens: ["Gluten", "Dairy", "Eggs"]
    },
    {
      id: "3",
      name: "Garden Veggie Bliss",
      description: "Plant-based patty, avocado, sprouts, vegan mayo",
      fullDescription: "A wholesome plant-based burger featuring our house-made quinoa and black bean patty, fresh avocado, alfalfa sprouts, cucumber, tomato, and creamy vegan mayo on a whole grain bun.",
      price: 12.99,
      image: "https://images.unsplash.com/photo-1522790683078-0cca6ee71460?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2ZWdnaWUlMjBidXJnZXIlMjBoZWFsdGh5fGVufDF8fHx8MTc1NTQzOTcxN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 4.7,
      prepTime: "8-10 min",
      ingredients: ["Plant-Based Patty", "Avocado", "Alfalfa Sprouts", "Cucumber", "Tomato", "Vegan Mayo", "Whole Grain Bun"],
      nutritionInfo: {
        calories: 420,
        protein: "18g",
        carbs: "52g",
        fat: "16g"
      },
      allergens: ["Gluten"]
    },
    {
      id: "4",
      name: "Bacon BBQ Beast",
      description: "Double beef, crispy bacon, BBQ sauce, onion rings",
      fullDescription: "The ultimate indulgence! Two 4oz beef patties, thick-cut applewood smoked bacon, tangy BBQ sauce, crispy onion rings, and melted cheddar cheese on a buttery brioche bun.",
      price: 16.99,
      image: "https://images.unsplash.com/photo-1654779974049-e7d13ca21a90?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYWNvbiUyMGJ1cmdlciUyMGNyaXNweXxlbnwxfHx8fDE3NTU0Mzk3MTd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      rating: 4.9,
      prepTime: "15-18 min",
      isPopular: true,
      ingredients: ["Double Beef Patties", "Applewood Bacon", "BBQ Sauce", "Onion Rings", "Cheddar Cheese", "Brioche Bun"],
      nutritionInfo: {
        calories: 890,
        protein: "52g",
        carbs: "48g",
        fat: "45g"
      },
      allergens: ["Gluten", "Dairy", "Eggs"]
    },
  ];

  const handleViewDetails = (burger: Burger) => {
    setSelectedBurger(burger);
    setQuantity(1);
  };

  return (
    <section className="py-20 bg-gradient-to-b from-yellow-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4"
          >
            Featured <span className="text-primary">Burgers</span>
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4 }}
            className="text-lg text-gray-600 max-w-2xl mx-auto"
          >
            Handcrafted burgers made with premium ingredients and unmatched flavor
          </motion.p>
        </motion.div>

        {/* Burger Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredBurgers.map((burger, index) => (
            <motion.div
              key={burger.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              onMouseEnter={() => setHoveredBurger(burger.id)}
              onMouseLeave={() => setHoveredBurger(null)}
              className="group cursor-pointer"
            >
              <Card className="overflow-hidden border-0 shadow-lg hover:shadow-2xl transition-all duration-500 bg-white">
                <div className="relative overflow-hidden">
                  {/* Badges */}
                  <div className="absolute top-4 left-4 z-10 flex flex-col space-y-2">
                    {burger.isPopular && (
                      <span className="bg-secondary text-black text-xs font-bold px-2 py-1 rounded-full">
                        🔥 Popular
                      </span>
                    )}
                    {burger.isSpicy && (
                      <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full flex items-center">
                        <Flame className="w-3 h-3 mr-1" />
                        Spicy
                      </span>
                    )}
                  </div>

                  {/* Burger Image */}
                  <motion.div
                    animate={{
                      scale: hoveredBurger === burger.id ? 1.1 : 1,
                      rotate: hoveredBurger === burger.id ? 5 : 0,
                    }}
                    transition={{ duration: 0.3 }}
                    className="aspect-square overflow-hidden"
                  >
                    <ImageWithFallback
                      src={burger.image}
                      alt={burger.name}
                      className="w-full h-full object-cover"
                    />
                  </motion.div>

                  {/* Hover Overlay */}
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{
                      opacity: hoveredBurger === burger.id ? 1 : 0,
                    }}
                    className="absolute inset-0 bg-black/20 flex items-center justify-center"
                  >
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{
                        scale: hoveredBurger === burger.id ? 1 : 0,
                      }}
                      transition={{ delay: 0.1 }}
                    >
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button 
                            className="bg-white text-primary hover:bg-gray-100 font-semibold"
                            onClick={() => handleViewDetails(burger)}
                          >
                            View Details
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
                          <DialogHeader>
                            <DialogTitle className="flex items-center space-x-2 text-2xl">
                              <span>{burger.name}</span>
                              {burger.isPopular && (
                                <Badge variant="secondary" className="font-bold">
                                  🔥 Popular
                                </Badge>
                              )}
                              {burger.isSpicy && (
                                <Badge className="bg-red-500 font-bold">
                                  <Flame className="w-3 h-3 mr-1" />
                                  Spicy
                                </Badge>
                              )}
                            </DialogTitle>
                            <DialogDescription>
                              {burger.fullDescription}
                            </DialogDescription>
                          </DialogHeader>
                          
                          <div className="space-y-6">
                            {/* Burger Image */}
                            <div className="aspect-video overflow-hidden rounded-lg">
                              <ImageWithFallback
                                src={burger.image}
                                alt={burger.name}
                                className="w-full h-full object-cover"
                              />
                            </div>

                            {/* Rating and Time */}
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-4">
                                <div className="flex items-center space-x-1">
                                  <Star className="w-5 h-5 fill-secondary text-secondary" />
                                  <span className="font-medium">{burger.rating}</span>
                                  <span className="text-gray-500 text-sm">(234 reviews)</span>
                                </div>
                                <div className="flex items-center space-x-1 text-gray-500">
                                  <Clock className="w-5 h-5" />
                                  <span>{burger.prepTime}</span>
                                </div>
                              </div>
                              <span className="text-3xl font-bold text-primary">
                                ${burger.price}
                              </span>
                            </div>

                            {/* Description */}
                            <div>
                              <h4 className="font-semibold mb-2">Description</h4>
                              <p className="text-gray-600">{burger.fullDescription}</p>
                            </div>

                            {/* Ingredients */}
                            <div>
                              <h4 className="font-semibold mb-3">Ingredients</h4>
                              <div className="flex flex-wrap gap-2">
                                {burger.ingredients.map((ingredient, index) => (
                                  <Badge key={index} variant="outline" className="text-sm">
                                    {ingredient}
                                  </Badge>
                                ))}
                              </div>
                            </div>

                            {/* Nutrition Info */}
                            <div>
                              <h4 className="font-semibold mb-3">Nutrition Information</h4>
                              <div className="grid grid-cols-4 gap-4 text-center">
                                <div className="bg-gray-50 p-3 rounded-lg">
                                  <div className="font-bold text-lg">{burger.nutritionInfo.calories}</div>
                                  <div className="text-sm text-gray-600">Calories</div>
                                </div>
                                <div className="bg-gray-50 p-3 rounded-lg">
                                  <div className="font-bold text-lg">{burger.nutritionInfo.protein}</div>
                                  <div className="text-sm text-gray-600">Protein</div>
                                </div>
                                <div className="bg-gray-50 p-3 rounded-lg">
                                  <div className="font-bold text-lg">{burger.nutritionInfo.carbs}</div>
                                  <div className="text-sm text-gray-600">Carbs</div>
                                </div>
                                <div className="bg-gray-50 p-3 rounded-lg">
                                  <div className="font-bold text-lg">{burger.nutritionInfo.fat}</div>
                                  <div className="text-sm text-gray-600">Fat</div>
                                </div>
                              </div>
                            </div>

                            {/* Allergens */}
                            <div>
                              <h4 className="font-semibold mb-2">Allergens</h4>
                              <p className="text-sm text-gray-600">
                                Contains: {burger.allergens.join(", ")}
                              </p>
                            </div>

                            {/* Quantity and Add to Cart */}
                            <div className="flex items-center justify-between bg-gray-50 p-4 rounded-lg">
                              <div className="flex items-center space-x-3">
                                <span className="font-medium">Quantity:</span>
                                <div className="flex items-center space-x-2">
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                                  >
                                    <Minus className="w-4 h-4" />
                                  </Button>
                                  <span className="w-8 text-center font-bold">{quantity}</span>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => setQuantity(quantity + 1)}
                                  >
                                    <Plus className="w-4 h-4" />
                                  </Button>
                                </div>
                              </div>
                              <Button className="bg-primary hover:bg-primary/90 font-semibold">
                                Add to Cart - ${(burger.price * quantity).toFixed(2)}
                              </Button>
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </motion.div>
                  </motion.div>
                </div>

                <CardContent className="p-6">
                  {/* Rating and Time */}
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-1">
                      <Star className="w-4 h-4 fill-secondary text-secondary" />
                      <span className="text-sm font-medium text-gray-700">
                        {burger.rating}
                      </span>
                    </div>
                    <div className="flex items-center space-x-1 text-gray-500">
                      <Clock className="w-4 h-4" />
                      <span className="text-sm">{burger.prepTime}</span>
                    </div>
                  </div>

                  {/* Burger Name */}
                  <h3 className="font-bold text-lg text-gray-900 mb-2 group-hover:text-primary transition-colors">
                    {burger.name}
                  </h3>

                  {/* Description */}
                  <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                    {burger.description}
                  </p>

                  {/* Price and Add Button */}
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-primary">
                      ${burger.price}
                    </span>
                    <motion.div
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <ModernButton 
                        size="sm" 
                        variant="primary"
                        onClick={() => {
                          addToCart({
                            id: burger.id,
                            name: burger.name,
                            price: burger.price,
                            image: burger.image
                          });
                          addToast({
                            type: 'success',
                            title: 'Added to Cart! 🎉',
                            description: `${burger.name} has been added to your cart.`,
                            action: {
                              label: 'View Cart',
                              onClick: () => {
                                addToast({
                                  type: 'info',
                                  title: 'Cart Summary',
                                  description: `${cartCount + 1} items • Total: $${(cartTotal + burger.price).toFixed(2)}`
                                });
                              }
                            }
                          });
                        }}
                      >
                        Add to Cart
                      </ModernButton>
                    </motion.div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* View All Button */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.6 }}
          className="text-center mt-12"
        >
          <Button 
            variant="outline" 
            size="lg"
            className="border-2 border-primary text-primary hover:bg-primary hover:text-white px-8 py-6 font-semibold rounded-full transition-all duration-300"
          >
            View Full Menu
          </Button>
        </motion.div>
      </div>
    </section>
  );
}