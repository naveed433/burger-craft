import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { motion } from "motion/react";
import { 
  Clock, 
  ChefHat, 
  Truck, 
  CheckCircle, 
  MapPin, 
  Phone,
  MessageCircle 
} from "lucide-react";

interface OrderStep {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  estimatedTime: string;
  isActive: boolean;
  isCompleted: boolean;
}

export function OrderTracker() {
  const [currentStep, setCurrentStep] = useState(1);
  const [orderData] = useState({
    orderNumber: "#BRG-2024-001",
    estimatedDelivery: "2:45 PM",
    driverName: "Alex Rodriguez",
    driverPhone: "+1 (555) 123-4567",
    items: [
      { name: "Classic Supreme Burger", quantity: 1, price: 14.99 },
      { name: "Spicy Chicken Deluxe", quantity: 1, price: 13.99 },
      { name: "Large Fries", quantity: 2, price: 5.98 },
    ],
    total: 34.96
  });

  const steps: OrderStep[] = [
    {
      id: "received",
      title: "Order Received",
      description: "We've got your order and it's being prepared",
      icon: <Clock className="w-6 h-6" />,
      estimatedTime: "Just now",
      isActive: currentStep === 0,
      isCompleted: currentStep > 0,
    },
    {
      id: "cooking",
      title: "Cooking",
      description: "Our chefs are crafting your perfect burger",
      icon: <ChefHat className="w-6 h-6" />,
      estimatedTime: "8-12 mins",
      isActive: currentStep === 1,
      isCompleted: currentStep > 1,
    },
    {
      id: "delivery",
      title: "Out for Delivery",
      description: "Your order is on its way to you",
      icon: <Truck className="w-6 h-6" />,
      estimatedTime: "10-15 mins",
      isActive: currentStep === 2,
      isCompleted: currentStep > 2,
    },
    {
      id: "delivered",
      title: "Delivered",
      description: "Enjoy your delicious burger!",
      icon: <CheckCircle className="w-6 h-6" />,
      estimatedTime: "Completed",
      isActive: currentStep === 3,
      isCompleted: currentStep > 3,
    },
  ];

  // Simulate order progress
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentStep(prev => {
        if (prev < 3) return prev + 1;
        clearInterval(timer);
        return prev;
      });
    }, 3000); // Change step every 3 seconds for demo

    return () => clearInterval(timer);
  }, []);

  return (
    <section id="track" className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            Track Your <span className="text-primary">Order</span>
          </h2>
          <p className="text-lg text-gray-600">
            Real-time updates on your burger's journey from kitchen to your door
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Order Progress */}
          <div className="lg:col-span-2">
            <Card className="bg-white shadow-xl">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center space-x-2">
                    <span>📋</span>
                    <span>Order {orderData.orderNumber}</span>
                  </CardTitle>
                  <div className="text-right">
                    <div className="text-sm text-gray-500">Estimated Delivery</div>
                    <div className="font-bold text-primary">{orderData.estimatedDelivery}</div>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {/* Progress Steps */}
                <div className="space-y-8">
                  {steps.map((step, index) => (
                    <motion.div
                      key={step.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="relative flex items-start space-x-4"
                    >
                      {/* Step Icon */}
                      <motion.div
                        animate={{
                          backgroundColor: step.isCompleted || step.isActive 
                            ? "var(--primary)" 
                            : "rgb(229, 231, 235)",
                          scale: step.isActive ? 1.1 : 1,
                        }}
                        className={`relative z-10 flex items-center justify-center w-12 h-12 rounded-full text-white`}
                      >
                        {step.isCompleted ? (
                          <motion.div
                            initial={{ scale: 0 }}
                            animate={{ scale: 1 }}
                            transition={{ type: "spring", bounce: 0.5 }}
                          >
                            <CheckCircle className="w-6 h-6" />
                          </motion.div>
                        ) : (
                          <motion.div
                            animate={{
                              color: step.isActive ? "white" : "rgb(107, 114, 128)"
                            }}
                          >
                            {step.icon}
                          </motion.div>
                        )}

                        {/* Pulsing animation for active step */}
                        {step.isActive && (
                          <motion.div
                            className="absolute inset-0 rounded-full bg-primary"
                            animate={{
                              scale: [1, 1.2, 1],
                              opacity: [0.7, 0.3, 0.7],
                            }}
                            transition={{
                              duration: 2,
                              repeat: Infinity,
                            }}
                          />
                        )}
                      </motion.div>

                      {/* Connecting Line */}
                      {index < steps.length - 1 && (
                        <motion.div
                          className="absolute left-6 top-12 w-0.5 h-16 bg-gray-200"
                          animate={{
                            backgroundColor: step.isCompleted 
                              ? "var(--primary)" 
                              : "rgb(229, 231, 235)"
                          }}
                        />
                      )}

                      {/* Step Content */}
                      <div className="flex-1 min-w-0">
                        <motion.h3
                          animate={{
                            color: step.isCompleted || step.isActive 
                              ? "var(--primary)" 
                              : "rgb(107, 114, 128)"
                          }}
                          className="font-semibold text-lg"
                        >
                          {step.title}
                        </motion.h3>
                        <p className="text-gray-600 text-sm mt-1">
                          {step.description}
                        </p>
                        <div className="text-xs text-gray-500 mt-2">
                          {step.estimatedTime}
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>

                {/* Driver Info (shows when out for delivery) */}
                {currentStep >= 2 && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-8 p-4 bg-primary/5 rounded-lg border border-primary/20"
                  >
                    <h4 className="font-semibold text-primary mb-3 flex items-center">
                      <Truck className="w-4 h-4 mr-2" />
                      Your Delivery Driver
                    </h4>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-primary text-white rounded-full flex items-center justify-center font-bold">
                          {orderData.driverName.split(' ').map(n => n[0]).join('')}
                        </div>
                        <div>
                          <div className="font-medium">{orderData.driverName}</div>
                          <div className="text-sm text-gray-600 flex items-center">
                            <Phone className="w-3 h-3 mr-1" />
                            {orderData.driverPhone}
                          </div>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">
                          <MessageCircle className="w-4 h-4 mr-1" />
                          Message
                        </Button>
                        <Button variant="outline" size="sm">
                          <MapPin className="w-4 h-4 mr-1" />
                          Track
                        </Button>
                      </div>
                    </div>
                  </motion.div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Order Summary */}
          <div>
            <Card className="bg-white shadow-xl sticky top-8">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <span>🛒</span>
                  <span>Order Summary</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Order Items */}
                <div className="space-y-3">
                  {orderData.items.map((item, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="flex justify-between items-start"
                    >
                      <div className="flex-1">
                        <div className="font-medium text-sm">{item.name}</div>
                        <div className="text-xs text-gray-500">Qty: {item.quantity}</div>
                      </div>
                      <div className="font-semibold text-sm">
                        ${item.price.toFixed(2)}
                      </div>
                    </motion.div>
                  ))}
                </div>

                {/* Total */}
                <div className="pt-3 border-t border-gray-200">
                  <div className="flex justify-between items-center">
                    <span className="font-bold">Total</span>
                    <span className="font-bold text-primary text-lg">
                      ${orderData.total.toFixed(2)}
                    </span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="pt-4 space-y-2">
                  <Button variant="outline" size="sm" className="w-full">
                    Modify Order
                  </Button>
                  <Button variant="outline" size="sm" className="w-full">
                    Contact Support
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}