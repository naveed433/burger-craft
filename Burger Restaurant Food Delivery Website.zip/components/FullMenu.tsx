import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { motion } from "motion/react";
import { Star, Clock, Flame, Leaf, Plus } from "lucide-react";

interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  rating: number;
  prepTime: string;
  isSpicy?: boolean;
  isVegan?: boolean;
  isPopular?: boolean;
  isNew?: boolean;
}

export function FullMenu() {
  const [selectedCategory, setSelectedCategory] = useState("burgers");

  const menuCategories = [
    { id: "burgers", name: "Burgers", icon: "🍔" },
    { id: "sides", name: "Sides", icon: "🍟" },
    { id: "drinks", name: "Drinks", icon: "🥤" },
    { id: "desserts", name: "Desserts", icon: "🍰" },
    { id: "salads", name: "Salads", icon: "🥗" },
  ];

  const menuItems: Record<string, MenuItem[]> = {
    burgers: [
      {
        id: "1",
        name: "The Classic Supreme",
        description: "Juicy beef patty, aged cheddar, crispy lettuce, tomato",
        price: 14.99,
        image: "https://images.unsplash.com/photo-1600555379885-08a02224726d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGVlc2VidXJnZXIlMjByZXN0YXVyYW50JTIwbWVhbHxlbnwxfHx8fDE3NTU0Mzk3MTZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        rating: 4.8,
        prepTime: "12-15 min",
        isPopular: true,
      },
      {
        id: "2",
        name: "Spicy Chicken Deluxe",
        description: "Crispy chicken breast, pepper jack, jalapeños, sriracha mayo",
        price: 13.99,
        image: "https://images.unsplash.com/photo-1643111998354-07e7a780c92b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGlja2VuJTIwYnVyZ2VyJTIwZGVsaWNpb3VzfGVufDF8fHx8MTc1NTM0NTczNHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        rating: 4.6,
        prepTime: "10-12 min",
        isSpicy: true,
      },
      {
        id: "3",
        name: "Garden Veggie Bliss",
        description: "Plant-based patty, avocado, sprouts, vegan mayo",
        price: 12.99,
        image: "https://images.unsplash.com/photo-1522790683078-0cca6ee71460?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2ZWdnaWUlMjBidXJnZXIlMjBoZWFsdGh5fGVufDF8fHx8MTc1NTQzOTcxN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        rating: 4.7,
        prepTime: "8-10 min",
        isVegan: true,
      },
      {
        id: "4",
        name: "Bacon BBQ Beast",
        description: "Double beef, crispy bacon, BBQ sauce, onion rings",
        price: 16.99,
        image: "https://images.unsplash.com/photo-1654779974049-e7d13ca21a90?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYWNvbiUyMGJ1cmdlciUyMGNyaXNweXxlbnwxfHx8fDE3NTU0Mzk3MTd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        rating: 4.9,
        prepTime: "15-18 min",
        isPopular: true,
      },
      {
        id: "5",
        name: "Mushroom Swiss Deluxe",
        description: "Beef patty, sautéed mushrooms, Swiss cheese, truffle mayo",
        price: 15.99,
        image: "https://images.unsplash.com/photo-1664232802830-592394491fd2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnb3VybWV0JTIwYnVyZ2VyJTIwZm9vZCUyMHBob3RvZ3JhcGh5fGVufDF8fHx8MTc1NTQzNTU0NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        rating: 4.5,
        prepTime: "14-16 min",
        isNew: true,
      },
      {
        id: "6",
        name: "Fish & Chips Burger",
        description: "Crispy fish fillet, tartar sauce, lettuce, pickles",
        price: 13.49,
        image: "https://images.unsplash.com/photo-1664232802830-592394491fd2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxnb3VybWV0JTIwYnVyZ2VyJTIwZm9vZCUyMHBob3RvZ3JhcGh5fGVufDF8fHx8MTc1NTQzNTU0NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        rating: 4.3,
        prepTime: "12-14 min",
      },
    ],
    sides: [
      {
        id: "s1",
        name: "Classic French Fries",
        description: "Golden crispy fries with sea salt",
        price: 4.99,
        image: "https://images.unsplash.com/photo-1734774797087-b6435057a15e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVuY2glMjBmcmllcyUyMGdvbGRlbiUyMGNyaXNweXxlbnwxfHx8fDE3NTU0NDA0OTd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        rating: 4.6,
        prepTime: "5-7 min",
        isPopular: true,
      },
      {
        id: "s2",
        name: "Sweet Potato Fries",
        description: "Crispy sweet potato fries with honey aioli",
        price: 5.99,
        image: "https://images.unsplash.com/photo-1734774797087-b6435057a15e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVuY2glMjBmcmllcyUyMGdvbGRlbiUyMGNyaXNweXxlbnwxfHx8fDE3NTU0NDA0OTd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        rating: 4.4,
        prepTime: "6-8 min",
      },
      {
        id: "s3",
        name: "Loaded Nachos",
        description: "Tortilla chips with cheese, jalapeños, sour cream",
        price: 8.99,
        image: "https://images.unsplash.com/photo-1734774797087-b6435057a15e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVuY2glMjBmcmllcyUyMGdvbGRlbiUyMGNyaXNweXxlbnwxfHx8fDE3NTU0NDA0OTd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        rating: 4.7,
        prepTime: "8-10 min",
        isSpicy: true,
      },
      {
        id: "s4",
        name: "Onion Rings",
        description: "Beer-battered crispy onion rings",
        price: 6.49,
        image: "https://images.unsplash.com/photo-1734774797087-b6435057a15e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVuY2glMjBmcmllcyUyMGdvbGRlbiUyMGNyaXNweXxlbnwxfHx8fDE3NTU0NDA0OTd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        rating: 4.5,
        prepTime: "7-9 min",
      },
    ],
    drinks: [
      {
        id: "d1",
        name: "Classic Vanilla Milkshake",
        description: "Creamy vanilla ice cream blended to perfection",
        price: 5.99,
        image: "https://images.unsplash.com/photo-1623400518585-164b430fbe74?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaWxrc2hha2UlMjBkZXNzZXJ0JTIwZHJpbmt8ZW58MXx8fHwxNzU1NDQwNTAwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        rating: 4.8,
        prepTime: "3-5 min",
        isPopular: true,
      },
      {
        id: "d2",
        name: "Chocolate Fudge Shake",
        description: "Rich chocolate shake with fudge swirl",
        price: 6.49,
        image: "https://images.unsplash.com/photo-1623400518585-164b430fbe74?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaWxrc2hha2UlMjBkZXNzZXJ0JTIwZHJpbmt8ZW58MXx8fHwxNzU1NDQwNTAwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        rating: 4.9,
        prepTime: "3-5 min",
      },
      {
        id: "d3",
        name: "Fresh Lemonade",
        description: "House-made lemonade with fresh mint",
        price: 3.99,
        image: "https://images.unsplash.com/photo-1623400518585-164b430fbe74?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaWxrc2hha2UlMjBkZXNzZXJ0JTIwZHJpbmt8ZW58MXx8fHwxNzU1NDQwNTAwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        rating: 4.4,
        prepTime: "2-3 min",
      },
      {
        id: "d4",
        name: "Craft Root Beer Float",
        description: "Artisan root beer with vanilla ice cream",
        price: 4.99,
        image: "https://images.unsplash.com/photo-1623400518585-164b430fbe74?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaWxrc2hha2UlMjBkZXNzZXJ0JTIwZHJpbmt8ZW58MXx8fHwxNzU1NDQwNTAwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        rating: 4.6,
        prepTime: "3-4 min",
      },
    ],
    desserts: [
      {
        id: "de1",
        name: "Triple Chocolate Brownie",
        description: "Warm brownie with chocolate sauce and ice cream",
        price: 7.99,
        image: "https://images.unsplash.com/photo-1623400518585-164b430fbe74?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaWxrc2hha2UlMjBkZXNzZXJ0JTIwZHJpbmt8ZW58MXx8fHwxNzU1NDQwNTAwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        rating: 4.8,
        prepTime: "8-10 min",
        isPopular: true,
      },
      {
        id: "de2",
        name: "Apple Pie à la Mode",
        description: "Classic apple pie with vanilla ice cream",
        price: 6.99,
        image: "https://images.unsplash.com/photo-1623400518585-164b430fbe74?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtaWxrc2hha2UlMjBkZXNzZXJ0JTIwZHJpbmt8ZW58MXx8fHwxNzU1NDQwNTAwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        rating: 4.5,
        prepTime: "6-8 min",
      },
    ],
    salads: [
      {
        id: "sa1",
        name: "Caesar Salad",
        description: "Crisp romaine, parmesan, croutons, caesar dressing",
        price: 9.99,
        image: "https://images.unsplash.com/photo-1522790683078-0cca6ee71460?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2ZWdnaWUlMjBidXJnZXIlMjBoZWFsdGh5fGVufDF8fHx8MTc1NTQzOTcxN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        rating: 4.3,
        prepTime: "5-7 min",
      },
      {
        id: "sa2",
        name: "Grilled Chicken Garden",
        description: "Mixed greens, grilled chicken, vegetables, vinaigrette",
        price: 12.99,
        image: "https://images.unsplash.com/photo-1522790683078-0cca6ee71460?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2ZWdnaWUlMjBidXJnZXIlMjBoZWFsdGh5fGVufDF8fHx8MTc1NTQzOTcxN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
        rating: 4.6,
        prepTime: "8-10 min",
        isPopular: true,
      },
    ],
  };

  return (
    <section id="menu" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            Our Full <span className="text-primary">Menu</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Explore our complete selection of handcrafted burgers, sides, drinks, and desserts
          </p>
        </motion.div>

        {/* Menu Categories */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-12"
        >
          <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="w-full">
            <TabsList className="grid grid-cols-5 w-full max-w-2xl mx-auto mb-8">
              {menuCategories.map((category) => (
                <TabsTrigger
                  key={category.id}
                  value={category.id}
                  className="flex flex-col items-center space-y-1 py-3"
                >
                  <span className="text-2xl">{category.icon}</span>
                  <span className="text-sm font-medium">{category.name}</span>
                </TabsTrigger>
              ))}
            </TabsList>

            {/* Menu Items */}
            {menuCategories.map((category) => (
              <TabsContent key={category.id} value={category.id}>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {menuItems[category.id]?.map((item, index) => (
                    <motion.div
                      key={item.id}
                      initial={{ opacity: 0, y: 30 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <Card className="overflow-hidden border-0 shadow-lg hover:shadow-xl transition-all duration-300 bg-white">
                        <div className="relative">
                          {/* Badges */}
                          <div className="absolute top-4 left-4 z-10 flex flex-col space-y-2">
                            {item.isPopular && (
                              <Badge variant="secondary" className="font-bold">
                                🔥 Popular
                              </Badge>
                            )}
                            {item.isNew && (
                              <Badge className="bg-green-500 font-bold">
                                ✨ New
                              </Badge>
                            )}
                            {item.isSpicy && (
                              <Badge className="bg-red-500 font-bold">
                                <Flame className="w-3 h-3 mr-1" />
                                Spicy
                              </Badge>
                            )}
                            {item.isVegan && (
                              <Badge className="bg-green-600 font-bold">
                                <Leaf className="w-3 h-3 mr-1" />
                                Vegan
                              </Badge>
                            )}
                          </div>

                          {/* Item Image */}
                          <div className="aspect-[4/3] overflow-hidden">
                            <ImageWithFallback
                              src={item.image}
                              alt={item.name}
                              className="w-full h-full object-cover hover:scale-110 transition-transform duration-300"
                            />
                          </div>
                        </div>

                        <CardContent className="p-6">
                          {/* Rating and Time */}
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center space-x-1">
                              <Star className="w-4 h-4 fill-secondary text-secondary" />
                              <span className="text-sm font-medium text-gray-700">
                                {item.rating}
                              </span>
                            </div>
                            <div className="flex items-center space-x-1 text-gray-500">
                              <Clock className="w-4 h-4" />
                              <span className="text-sm">{item.prepTime}</span>
                            </div>
                          </div>

                          {/* Item Name */}
                          <h3 className="font-bold text-lg text-gray-900 mb-2">
                            {item.name}
                          </h3>

                          {/* Description */}
                          <p className="text-gray-600 text-sm mb-4">
                            {item.description}
                          </p>

                          {/* Price and Add Button */}
                          <div className="flex items-center justify-between">
                            <span className="text-2xl font-bold text-primary">
                              ${item.price}
                            </span>
                            <motion.div
                              whileHover={{ scale: 1.05 }}
                              whileTap={{ scale: 0.95 }}
                            >
                              <Button 
                                size="sm" 
                                className="bg-primary hover:bg-primary/90"
                              >
                                <Plus className="w-4 h-4 mr-1" />
                                Add to Cart
                              </Button>
                            </motion.div>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </motion.div>

        {/* Special Offers */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-gradient-to-r from-primary to-red-600 rounded-2xl p-8 text-white text-center"
        >
          <h3 className="text-2xl font-bold mb-4">🎉 Special Offers</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
              <h4 className="font-bold mb-2">Burger Combo Deal</h4>
              <p className="text-sm opacity-90">Any burger + fries + drink for just $18.99</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
              <h4 className="font-bold mb-2">Family Pack</h4>
              <p className="text-sm opacity-90">4 burgers + 4 sides + 4 drinks for $59.99</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
              <h4 className="font-bold mb-2">Happy Hour</h4>
              <p className="text-sm opacity-90">50% off milkshakes 3-5 PM daily</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}