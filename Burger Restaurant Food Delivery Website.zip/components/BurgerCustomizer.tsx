import { useState } from "react";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Checkbox } from "./ui/checkbox";
import { Badge } from "./ui/badge";
import { motion, AnimatePresence } from "motion/react";
import { Plus, Minus, ShoppingCart, Zap } from "lucide-react";

interface Ingredient {
  id: string;
  name: string;
  price: number;
  emoji: string;
  category: 'protein' | 'cheese' | 'vegetables' | 'sauces' | 'extras';
  calories: number;
}

interface SelectedIngredient extends Ingredient {
  quantity: number;
}

export function BurgerCustomizer() {
  const [selectedIngredients, setSelectedIngredients] = useState<SelectedIngredient[]>([
    { id: 'beef-patty', name: 'Beef Patty', price: 0, emoji: '🥩', category: 'protein', calories: 250, quantity: 1 }
  ]);

  const ingredients: Ingredient[] = [
    // Proteins
    { id: 'beef-patty', name: 'Beef Patty', price: 0, emoji: '🥩', category: 'protein', calories: 250 },
    { id: 'chicken-breast', name: 'Chicken Breast', price: 1.50, emoji: '🐔', category: 'protein', calories: 180 },
    { id: 'veggie-patty', name: 'Veggie Patty', price: 2.00, emoji: '🌱', category: 'protein', calories: 120 },
    
    // Cheese
    { id: 'cheddar', name: 'Cheddar', price: 1.00, emoji: '🧀', category: 'cheese', calories: 80 },
    { id: 'swiss', name: 'Swiss', price: 1.25, emoji: '🧀', category: 'cheese', calories: 85 },
    { id: 'pepper-jack', name: 'Pepper Jack', price: 1.25, emoji: '🧀', category: 'cheese', calories: 90 },
    
    // Vegetables
    { id: 'lettuce', name: 'Lettuce', price: 0.50, emoji: '🥬', category: 'vegetables', calories: 5 },
    { id: 'tomato', name: 'Tomato', price: 0.50, emoji: '🍅', category: 'vegetables', calories: 10 },
    { id: 'onion', name: 'Red Onion', price: 0.50, emoji: '🧅', category: 'vegetables', calories: 8 },
    { id: 'pickles', name: 'Pickles', price: 0.50, emoji: '🥒', category: 'vegetables', calories: 3 },
    { id: 'avocado', name: 'Avocado', price: 2.00, emoji: '🥑', category: 'vegetables', calories: 160 },
    
    // Sauces
    { id: 'mayo', name: 'Mayo', price: 0.25, emoji: '🥄', category: 'sauces', calories: 50 },
    { id: 'ketchup', name: 'Ketchup', price: 0.25, emoji: '🍅', category: 'sauces', calories: 20 },
    { id: 'mustard', name: 'Mustard', price: 0.25, emoji: '🟡', category: 'sauces', calories: 15 },
    { id: 'bbq', name: 'BBQ Sauce', price: 0.50, emoji: '🍖', category: 'sauces', calories: 30 },
    
    // Extras
    { id: 'bacon', name: 'Bacon', price: 2.50, emoji: '🥓', category: 'extras', calories: 120 },
    { id: 'onion-rings', name: 'Onion Rings', price: 1.50, emoji: '🔴', category: 'extras', calories: 150 },
  ];

  const categories = [
    { id: 'protein', name: 'Protein', icon: '🥩' },
    { id: 'cheese', name: 'Cheese', icon: '🧀' },
    { id: 'vegetables', name: 'Vegetables', icon: '🥬' },
    { id: 'sauces', name: 'Sauces', icon: '🥄' },
    { id: 'extras', name: 'Extras', icon: '🥓' },
  ];

  const toggleIngredient = (ingredient: Ingredient) => {
    setSelectedIngredients(prev => {
      const existing = prev.find(item => item.id === ingredient.id);
      if (existing) {
        return prev.filter(item => item.id !== ingredient.id);
      } else {
        return [...prev, { ...ingredient, quantity: 1 }];
      }
    });
  };

  const updateQuantity = (id: string, change: number) => {
    setSelectedIngredients(prev => 
      prev.map(item => {
        if (item.id === id) {
          const newQuantity = Math.max(0, item.quantity + change);
          return newQuantity === 0 ? null : { ...item, quantity: newQuantity };
        }
        return item;
      }).filter(Boolean) as SelectedIngredient[]
    );
  };

  const basePrice = 8.99;
  const totalPrice = basePrice + selectedIngredients.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const totalCalories = selectedIngredients.reduce((sum, item) => sum + (item.calories * item.quantity), 0);

  const isSelected = (ingredientId: string) => selectedIngredients.some(item => item.id === ingredientId);

  return (
    <section id="customize" className="py-20 bg-gradient-to-br from-red-50 to-yellow-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
            Customize Your <span className="text-primary">Perfect Burger</span>
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Build your dream burger with premium ingredients. Watch it come together in real-time!
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* 3D Burger Builder */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="order-2 lg:order-1"
          >
            <Card className="h-full bg-white shadow-xl">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <span>🍔</span>
                  <span>Your Burger</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {/* Burger Visualization */}
                <div className="relative min-h-96 flex flex-col items-center justify-center space-y-2 py-8">
                  {/* Top Bun */}
                  <motion.div
                    initial={{ y: -20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    className="text-6xl"
                  >
                    🍞
                  </motion.div>

                  {/* Ingredients Stack */}
                  <AnimatePresence>
                    {selectedIngredients.map((ingredient, index) => (
                      <motion.div
                        key={`${ingredient.id}-${index}`}
                        initial={{ y: -30, opacity: 0, scale: 0.8 }}
                        animate={{ y: 0, opacity: 1, scale: 1 }}
                        exit={{ y: -30, opacity: 0, scale: 0.8 }}
                        transition={{ 
                          type: "spring", 
                          bounce: 0.5,
                          delay: index * 0.1 
                        }}
                        className="text-5xl relative"
                      >
                        {ingredient.emoji}
                        {ingredient.quantity > 1 && (
                          <Badge 
                            variant="secondary" 
                            className="absolute -top-2 -right-2 text-xs"
                          >
                            {ingredient.quantity}x
                          </Badge>
                        )}
                      </motion.div>
                    ))}
                  </AnimatePresence>

                  {/* Bottom Bun */}
                  <motion.div
                    initial={{ y: 20, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    className="text-6xl"
                  >
                    🍞
                  </motion.div>
                </div>

                {/* Nutrition & Price Info */}
                <div className="bg-gray-50 rounded-lg p-4 space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Total Price:</span>
                    <span className="text-2xl font-bold text-primary">${totalPrice.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-medium">Total Calories:</span>
                    <span className="font-semibold">{totalCalories} cal</span>
                  </div>
                  
                  <motion.div
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="pt-2"
                  >
                    <Button 
                      size="lg" 
                      className="w-full bg-primary hover:bg-primary/90 text-white font-semibold"
                    >
                      <ShoppingCart className="w-5 h-5 mr-2" />
                      Add to Cart - ${totalPrice.toFixed(2)}
                    </Button>
                  </motion.div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Ingredient Selection */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="order-1 lg:order-2 space-y-6"
          >
            {categories.map((category) => (
              <Card key={category.id} className="bg-white shadow-lg">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center space-x-2">
                    <span className="text-2xl">{category.icon}</span>
                    <span>{category.name}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-3">
                    {ingredients
                      .filter(ingredient => ingredient.category === category.id)
                      .map((ingredient) => {
                        const selected = isSelected(ingredient.id);
                        const selectedItem = selectedIngredients.find(item => item.id === ingredient.id);
                        
                        return (
                          <motion.div
                            key={ingredient.id}
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            className={`relative border-2 rounded-lg p-3 cursor-pointer transition-all duration-200 ${
                              selected 
                                ? 'border-primary bg-primary/5' 
                                : 'border-gray-200 hover:border-gray-300'
                            }`}
                            onClick={() => toggleIngredient(ingredient)}
                          >
                            <div className="flex items-center space-x-2">
                              <Checkbox 
                                checked={selected}
                                onChange={() => {}}
                                className="pointer-events-none"
                              />
                              <span className="text-xl">{ingredient.emoji}</span>
                            </div>
                            
                            <div className="mt-2">
                              <div className="font-medium text-sm">{ingredient.name}</div>
                              <div className="text-xs text-gray-500">
                                +${ingredient.price.toFixed(2)} • {ingredient.calories} cal
                              </div>
                            </div>

                            {selected && selectedItem && (
                              <motion.div
                                initial={{ opacity: 0, scale: 0.8 }}
                                animate={{ opacity: 1, scale: 1 }}
                                className="absolute -top-2 -right-2 bg-white border border-gray-200 rounded-full flex items-center"
                              >
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    updateQuantity(ingredient.id, -1);
                                  }}
                                  className="w-6 h-6 flex items-center justify-center hover:bg-gray-100 rounded-l-full"
                                >
                                  <Minus className="w-3 h-3" />
                                </button>
                                <span className="w-6 text-center text-sm font-bold">
                                  {selectedItem.quantity}
                                </span>
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    updateQuantity(ingredient.id, 1);
                                  }}
                                  className="w-6 h-6 flex items-center justify-center hover:bg-gray-100 rounded-r-full"
                                >
                                  <Plus className="w-3 h-3" />
                                </button>
                              </motion.div>
                            )}

                            {selected && (
                              <motion.div
                                initial={{ scale: 0 }}
                                animate={{ scale: 1 }}
                                className="absolute top-1 right-1"
                              >
                                <Zap className="w-4 h-4 text-secondary fill-secondary" />
                              </motion.div>
                            )}
                          </motion.div>
                        );
                      })}
                  </div>
                </CardContent>
              </Card>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}